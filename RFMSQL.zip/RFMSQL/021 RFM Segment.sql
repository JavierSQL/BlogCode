CREATE OR ALTER VIEW Demos.SegmentClassificationRFM
AS 
	WITH BaseNumbers AS (
		SELECT N
		FROM (VALUES(1),(2), (3), (4), (5)) AS V(N)
	), RFM AS (
		SELECT CAST(B1.N*100+B2.N*10+B3.N AS VARCHAR(3)) AS RFM
			, B1.N AS R
			, B2.N AS F
			, B3.N AS M
		FROM BaseNumbers AS B1
		CROSS JOIN BaseNumbers AS B2
		CROSS JOIN BaseNumbers AS B3
	), RFMSegments AS(
		SELECT *
		FROM (VALUES
			  (1, 'Estrellas'						)		--- Champions
			, (2, 'Adeptos'							)		--- Loyal Customers
			, (3, 'Adeptos Potenciales'				)		--- Potential Loyalist
			, (4, 'Nuevos/Recientes'				)		--- Promising/New
			, (5, 'Estrellas Desvanecientes'		)		--- 'Can�t Lose Them'
			, (6, 'Adeptos Desvanecientes'			)		--- At Risk
			, (7, 'Modestos'						)		--- Need Attention
			, (8, 'Dormidos'						))		--- Lost/Hibernating
				AS C(SegmentCode, SegmentName)
	)
	SELECT 
		   RFM.RFM
		, S.SegmentCode
		, S.SegmentName

	FROM RFM
	CROSS APPLY (
			SELECT CASE 
				WHEN R>=4	AND F+M>=9	THEN 1
				WHEN R>=3	AND F+M>=7	THEN 2
				WHEN R>=4	AND F+M>=4	THEN 3
				WHEN R>=4	AND F+M<5	THEN 4
				WHEN R<=2	AND F+M>=8	THEN 5
				WHEN R<=2	AND F+M>=6	THEN 6
				WHEN R>=2	AND F+M>=4	THEN 7
				WHEN R<=3	AND F+M<=5	THEN 8
				---ELSE NULL
			END AS CType) AS T
	JOIN RFMSegments AS S 
		ON T.CType=S.SegmentCode
GO

