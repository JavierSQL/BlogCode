CREATE OR ALTER   VIEW Demos.SalesOrders
AS
	SELECT SalesOrderID, OrderDate, DueDate, ShipDate, CustomerID, SalesPersonID, TerritoryID, BillToAddressID, ShipToAddressID, ShipMethodID, CreditCardID, SubTotal, TaxAmt, Freight, TotalDue
	FROM Demos.SalesOrderHeader AS OH
	
GO

