DROP TABLE IF EXISTS Demos.SalesOrderHeader;
GO
--- Ajusta las fechas para que sean recientes, ya que AdventureWorks ya esta muy vieja
	SELECT SalesOrderID, 
			D.OrderDate, 
			D.DueDate, 
			D.ShipDate,
			CustomerID, 
			SalesPersonID,        
			TerritoryID,        
			BillToAddressID,        
			ShipToAddressID,        
			ShipMethodID,        
			CreditCardID,       
			SubTotal,
			TaxAmt,        
			Freight,        
			TotalDue
INTO Demos.SalesOrderHeader
FROM Sales.SalesOrderHeader AS OH
CROSS APPLY (
SELECT 	CAST(DATEADD(MONTH,-1, DATEADD(YEAR, 9, OrderDate)) AS DATE) AS OrderDate, 
		CAST(DATEADD(MONTH,-1, DATEADD(YEAR, 9, DueDate)) AS DATE) AS DueDate, 
		CAST(DATEADD(MONTH,-1, DATEADD(YEAR, 9, ShipDate)) AS DATE) AS ShipDate
) AS D
WHERE D.OrderDate<='20230331'

GO
-- Arregla situacion de todas las ordenes de tiendas se emiten el ultimo dia del mes
-- No permite ver Recencia.
UPDATE SO
	SET OrderDate = DATEADD(DAY, -ABS(CHECKSUM(NEWID()))%30, OrderDate)
FROM Demos.SalesOrderHeader AS SO
JOIN Sales.Customer AS Cus
	ON SO.CustomerID=Cus.CustomerID
JOIN Sales.Store AS S
    ON Cus.StoreID=S.BusinessEntityID;
GO

CREATE UNIQUE CLUSTERED INDEX IDX_Demos_SalesOrderHeader
ON Demos.SalesOrderHeader(OrderDate, SalesOrderID);

