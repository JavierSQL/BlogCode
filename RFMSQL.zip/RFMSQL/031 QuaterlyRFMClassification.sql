CREATE OR ALTER VIEW Demos.QuaterlyRFMClassification AS
	WITH CustomerType as (
		SELECT S.CustomerID, 'Store' AS CustomerType, 4 AS CustomerQ
		FROM Demos.Stores AS S
		UNION ALL 
		SELECT S.CustomerID, 'Individual' AS CustomerType, 8 as CustomerQ
		FROM Demos.Individuals AS S
	)
	, Customers AS (
		SELECT SO.CustomerID
			, CT.CustomerType
			, EOMONTH(MIN(OrderDate))										AS FirstOrderEOM
			, DATEADD(MONTH, MAX(CT.CustomerQ), EOMONTH(MAX(OrderDate)))	AS LastMonthCustomer
			, CT.CustomerQ
		FROM Demos.SalesOrders AS SO
		JOIN CustomerType AS CT
			ON CT.CustomerID=SO.CustomerID
		GROUP BY SO.CustomerID, CT.CustomerType, CT.CustomerQ
	)
	, Quarters AS (
		SELECT DISTINCT EndOfQuarter
		FROM Demos.Dates
		WHERE EndOfMonth <=(SELECT MAX(OrderDate)
							FROM Demos.SalesOrders)
	), CustomerBase AS (
		SELECT C.CustomerID, C.CustomerType, Q.EndOfQuarter, C.CustomerQ
		FROM Customers AS C 
		JOIN Quarters AS Q
			ON Q.EndOfQuarter BETWEEN C.FirstOrderEOM 
									AND C.LastMonthCustomer
	), CustomerRFMValues AS ( 
	SELECT BC.CustomerID, BC.CustomerType, BC.EndOfQuarter
		, RFM.RValue
		, RFM.FValue
		, RFM.MValue
		, COUNT(*) OVER(PARTITION BY CustomerType, EndOfQuarter
			 ORDER BY CustomerID
			 ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING ) AS TotalRows
	FROM CustomerBase AS BC
	OUTER APPLY (
		SELECT    DATEDIFF(day, MAX(OrderDate), bc.EndOfQuarter) AS RValue
				, COUNT(*) AS FValue
				, SUM(SO.SubTotal) AS MValue
		FROM Demos.SalesOrders AS SO
		WHERE BC.CustomerID=SO.CustomerID
			AND SO.OrderDate BETWEEN DATEADD(DAY, 1, DATEADD(QUARTER, -BC.CustomerQ, BC.EndOfQuarter))
				AND BC.EndOfQuarter
	) AS RFM
	WHERE RFM.MValue IS NOT NULL
)
SELECT CustomerID, EndOfQuarter
		, CEILING(5.0 *RANK() OVER(PARTITION BY CustomerType, EndOfQuarter
				 ORDER BY RValue DESC)
			/ TotalRows) * 100
		+  CEILING(5.0 *RANK() OVER(PARTITION BY CustomerType, EndOfQuarter
				 ORDER BY FValue )
			/ TotalRows) * 10
		+ CEILING(5.0 *RANK() OVER(PARTITION BY CustomerType, EndOfQuarter
				 ORDER BY MValue)
			/ TotalRows) AS RFM
FROM CustomerRFMValues
GO
SELECT top 10 CustomerID, COUNT(DISTINCT RFM)
FROM Demos.QuaterlyRFMClassification
GROUP BY CustomerID
ORDER BY 2 desc

select * FROM Demos.QuaterlyRFMClassification
where CustomerID=29824



