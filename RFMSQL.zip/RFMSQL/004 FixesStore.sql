--- Correccion de Datos de Individuos

DROP TABLE IF EXISTS #PosibleBuyers;
SELECT CustomerID
INTO  #PosibleBuyers
FROM Demos.ActualRFM
WHERE CustomerType='Store'
	AND FValue=4
--389

SET IDENTITY_INSERT Demos.SalesOrderHeader ON;  
; WITH LastOrder AS(
	SELECT MAX(SalesOrderID) AS LastOrder
	FROM Demos.SalesOrderHeader
)
, Fixes AS (
	SELECT *
		, COALESCE(SUM(Customers ) 
			OVER(ORDER BY Orders DESC
			ROWS BETWEEN unbounded preceding AND 1 PRECEDING)
			, 0)+1
			AS StartPos
		, SUM(Customers ) 
			OVER(ORDER BY Orders DESC
			ROWS BETWEEN unbounded preceding AND Current ROW)
			AS EndPos
	FROM (VALUES
			(50, 4 ),
			(50, 3 ),
			(90, 2 ),
			(90, 1 )) AS S(Customers, Orders)
)
, CustomerSel AS (
	-- Enlazado con el numero total anterior
	SELECT TOP 280 CustomerID, ROW_NUMBER()
		OVER(ORDER BY CHECKSUM(NEWID())) 
		AS CustPos
	FROM #PosibleBuyers
)
, CustomerOrd AS (
	SELECT CustomerID
		, F.Orders
		, ROW_NUMBER()
			OVER(ORDER BY CHECKSUM(NEWID())) 
			AS OPos
	FROM CustomerSel AS C
	JOIN Fixes  AS F
		ON C.CustPos BETWEEN F.StartPos AND F.EndPos
	CROSS APPLY(
		SELECT *
		FROM (VALUES(1),(2),(3),(4)) AS N(NOrden)
		WHERE N.NOrden<=F.Orders) AS N
--626
)
, OrdersSel AS (
	SELECT ROW_NUMBER()
			OVER(ORDER BY CHECKSUM(NEWID())) 
			AS OPos
			, SO.*
	FROM  Demos.SalesOrderHeader AS SO
	CROSS APPLY(
		SELECT *
		FROM (VALUES(1),(2),(3),(4)) AS N(NOrden)
		) AS N
	JOIN Sales.Customer AS Cus
		ON SO.CustomerID=Cus.CustomerID
     JOIN Sales.Store AS S
		ON Cus.StoreID=S.BusinessEntityID
	WHERE SO.OrderDate>=DATEADD(QUARTER, -4, '2023-03-31')
)
INSERT Demos.SalesOrderHeader(
SalesOrderID, OrderDate, DueDate, ShipDate, CustomerID, SalesPersonID, TerritoryID, BillToAddressID, ShipToAddressID, ShipMethodID, CreditCardID, SubTotal, TaxAmt, Freight, TotalDue
)
SELECT LO.LastOrder+O.OPos AS SalesOrderID
	, O.OrderDate, O.DueDate, O.ShipDate
	, C.CustomerID
	, O.SalesPersonID, O.TerritoryID, O.BillToAddressID, O.ShipToAddressID, O.ShipMethodID, O.CreditCardID, O.SubTotal, O.TaxAmt, O.Freight, O.TotalDue
FROM CustomerOrd AS C
JOIN OrdersSel AS O
	ON C.OPos=O.OPos
CROSS APPLY LastOrder AS LO

SET IDENTITY_INSERT Demos.SalesOrderHeader OFF;  

GO
