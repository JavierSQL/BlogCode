CREATE OR ALTER VIEW Demos.ActualRFM AS
	WITH CustomerType as (
		-- Nos fijamos en el ultimo a�o de compras
		SELECT S.CustomerID, 'Store' AS CustomerType		, 4 AS CustomerQ
		FROM Demos.Stores AS S
		UNION ALL 
		-- Nos fijamos en los ultimos dos a�os de compras
		SELECT S.CustomerID, 'Individual' AS CustomerType	, 8 as CustomerQ
		FROM Demos.Individuals AS S
	), PreviousQuarter AS (
		-- Cortada los datos al cuarto anterior en la vista SalesOrders
		SELECT 	CAST(MAX(OrderDate) AS DATE) AS PreviousQuarter
		FROM Demos.SalesOrders
	)
	, RFMValues AS (
		SELECT SO.CustomerID
			, MAX(CT.CustomerType) AS CustomerType
			--- Calculo de Valores RFM
			, DATEDIFF(day, MAX(OrderDate), MAX(MQ.PreviousQuarter))	AS RValue
			, COUNT(*)													AS FValue
			, SUM(SO.SubTotal)											AS MValue

			, COUNT(*) OVER(PARTITION BY MAX(CT.CustomerType) 
				 ORDER BY SO.CustomerID
				 ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING ) AS TotalRows
		FROM Demos.SalesOrders AS SO
		JOIN CustomerType AS CT
			ON CT.CustomerID=SO.CustomerID
		CROSS JOIN PreviousQuarter AS MQ
		WHERE SO.OrderDate BETWEEN
			DATEADD(DAY, 1, DATEADD(QUARTER, -CT.CustomerQ, MQ.PreviousQuarter))
				AND MQ.PreviousQuarter
		GROUP BY SO.CustomerID
		HAVING  SUM(SO.SubTotal) IS NOT NULL
	)
	SELECT  RFM.CustomerID
		 , RFM.CustomerType
			, RFM.RValue, RFM.FValue, RFM.MValue
		--- NOTA: En caso de empates la  funcion NO es deterministica
		--- puede asignar algunas veces un cliente a un grupo y otras a otro
		--, NTILE(5) OVER(PARTITION BY CustomerType
		--		ORDER BY RValue) AS R
		--, NTILE(5) OVER(PARTITION BY CustomerType
		--		ORDER BY FValue DESC) AS F
		--, NTILE(5) OVER(PARTITION BY CustomerType
		--		ORDER BY MValue DESC) AS M

		, CEILING(5.0 *RANK() OVER(PARTITION BY CustomerType
				 ORDER BY RValue DESC)
			/ TotalRows) AS R
		, CEILING(5.0 *RANK() OVER(PARTITION BY CustomerType
				 ORDER BY FValue )
			/ TotalRows) AS F
		, CEILING(5.0 *RANK() OVER(PARTITION BY CustomerType
				 ORDER BY MValue)
			/ TotalRows) AS M

	FROM RFMValues AS RFM 
	GO




