DECLARE @CustomerType VARCHAR(20) = 'Store'	--- 'Individual'

SELECT R,  MIN(RValue) AS MinValue, MAX(RValue) AS MaxValue, COUNT(*) AS Rows
FROM Demos.ActualRFM
WHERE CustomerType=@CustomerType
GROUP BY R
SELECT F,  MIN(FValue) AS MinValue, MAX(FValue) AS MaxValue, COUNT(*) AS Rows
FROM Demos.ActualRFM
WHERE CustomerType=@CustomerType
GROUP BY F
SELECT M,  MIN(MValue) AS MinValue, MAX(MValue) AS MaxValue, COUNT(*) AS Rows
FROM Demos.ActualRFM
WHERE CustomerType=@CustomerType
GROUP BY M

SELECT * FROM DEMOS.Stores
WHERE NAME LIKE  '%GOLF%'

SELECT * FROM DEMOS.ActualRFM
WHERE CustomerID=29562

SELECT * FROM  Demos.SalesOrders
WHERE CustomerID=29562
ORDER BY OrderDate
