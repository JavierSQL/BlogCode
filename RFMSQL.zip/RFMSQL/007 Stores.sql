CREATE OR ALTER VIEW Demos.Stores AS 
    WITH BaseStore AS (
        SELECT 
            Cus.CustomerID
            ,s.Name 
            ,at.Name AS AddressType
            ,a.AddressLine1 
            ,a.AddressLine2 
            ,a.City 
            ,sp.Name AS StateProvinceName 
            ,a.PostalCode 
            ,cr.Name AS CountryRegionName 
            , ROW_NUMBER() OVER(PARTITION BY Cus.CustomerID
                ORDER BY CASE at.Name WHEN 'Main Office'  THEN 1    
                                      WHEN 'Primary'  THEN 2      
                                      WHEN 'Billing'  THEN 3    
                                      ELSE 4 END, bea.AddressTypeID ) AS RSel
        FROM Sales.Customer AS Cus
        JOIN Sales.Store AS S
            ON Cus.StoreID=S.BusinessEntityID
        --- Dups
        INNER JOIN Person.BusinessEntityAddress AS bea 
            ON bea.BusinessEntityID = s.BusinessEntityID 
        INNER JOIN Person.Address AS a 
            ON a.AddressID = bea.AddressID
        INNER JOIN Person.StateProvince AS sp 
            ON sp.StateProvinceID = a.StateProvinceID
        INNER JOIN Person.CountryRegion AS cr 
            ON cr.CountryRegionCode = sp.CountryRegionCode
        INNER JOIN Person.AddressType AS at 
            ON at.AddressTypeID = bea.AddressTypeID
        WHERE Cus.StoreID IS NOT NULL
        AND Cus.CustomerID IN (SELECT  oh.CustomerID
            FROM Sales.SalesOrderHeader AS OH)
    )
    SELECT CustomerID, Name, AddressType, AddressLine1, AddressLine2, City, StateProvinceName, PostalCode
        , CountryRegionName 
    FROM BaseStore
    WHERE RSel=1;
GO
SELECT TOP 20 * 
FROM Demos.Stores;